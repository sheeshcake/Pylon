


<?php $__env->startSection('styles'); ?>
    <link href="<?php echo e(url('/')); ?>/css/style.min.css" rel="stylesheet">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="page-wrapper">
            <div class="page-breadcrumb">
                <div class="row align-items-center">
                    <div class="col-md-6 col-8 align-self-center">
                        <h3 class="page-title mb-0 p-0">Portfolios</h3>
                        <div class="d-flex align-items-center">
                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="#">Portfolios</a></li>
                                </ol>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
            <div class="container-fluid">
                <?php if(\Session::has('success')): ?>
                    <div class="alert alert-success"><?php echo \Session::get('success'); ?></div>
                <?php endif; ?>
                <div class="row">
                    <div class="col-lg-10 col-md-8">
                        <a href="<?php echo e(route('newblog')); ?>" class="btn btn-success mb-3">Add New Portfolio</a>
                        <?php $__currentLoopData = $data['portfolios']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="card">
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col">
                                            <h3><?php echo e($blog->blog_title); ?></h3>
                                        </div>
                                        <div class="col-md-2">
                                            <a href="/blogs/removeblog/<?php echo e($blog->id); ?>" class="btn btn-danger mx-1">Delete</a>
                                            <a href="/blogs/viewblog/<?php echo e($blog->id); ?>" class="btn btn-primary mx-1">Edit</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <div class="col-lg-2 col md-4">
                        <div class="card">
                            <div class="card-header">
                                <h3>Categories</h3>
                            </div>
                            <div class="card-body">
                                <div id="category-alert" style="display: none"></div>
                                <?php $__currentLoopData = $data["categories"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="input-group">
                                        <input type="text" id="input_cat_<?php echo e($category->id); ?>" class="form-control" value="<?php echo e($category->category_name); ?>">
                                        <div class="input-group-prepend input-group-append">
                                            <button class="btn btn-outline-success updatecat" value="<?php echo e($category->id); ?>">
                                                <i class="fa fa-refresh" aria-hidden="true"></i>
                                            </button>
                                        </div>
                                        <div class="input-group-append">
                                            <button class="btn btn-outline-danger deletecat" value="<?php echo e($category->id); ?>">
                                                <i class="fa fa-trash" aria-hidden="true"></i>
                                            </button>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <hr>
                                <form action="categories/addcategory" method="post">
                                    <?php echo csrf_field(); ?>
                                    <label for="">Add Category</label>
                                    <div class="input-group">
                                        <input type="text" name="category_name" class="form-control" placeholder="Category Name">
                                        <div class="input-group-append">
                                            <input type="submit" class="btn btn-outline-success" value="Add">
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

<script src="<?php echo e(url('/')); ?>/assets/plugins/jquery/dist/jquery.min.js"></script>
<script src="<?php echo e(url('/')); ?>/assets/plugins/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
<script src="<?php echo e(url('/')); ?>/js/app-style-switcher.js"></script>
<script src="<?php echo e(url('/')); ?>/js/waves.js"></script>
<script src="<?php echo e(url('/')); ?>/js/sidebarmenu.js"></script>
<script src="<?php echo e(url('/')); ?>/js/custom.js"></script>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Pylon\Documents\LaravelWorkspace\Pylon\resources\views/content/portfolio.blade.php ENDPATH**/ ?>